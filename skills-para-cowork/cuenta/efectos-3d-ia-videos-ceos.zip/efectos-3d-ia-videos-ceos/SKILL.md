---
name: "efectos-3d-ia-videos-ceos"
description: "Añadir a los vídeos de Ceos Growth croma, animaciones 3D, fondos y clips generados con IA y recursos visuales avanzados, integrados con el estilo de editar-ad-ceos."
---

# Efectos 3D, croma e IA para vídeos · Ceos Growth

Complementa a editar-ad-ceos (sus reglas de marca, cara libre, subtítulos y audio siguen mandando). Usar para: quitar o cambiar el fondo de la actriz, meterla en escenas, animaciones 3D (logo del caballo, bolas, casas, gráficas, texto), y b-roll o fondos generados con IA. Regla de oro: el efecto sirve al mensaje. Pocos y en los momentos clave; si distrae de lo que dice la actriz, fuera.

## 1. Croma y recorte de la actriz
**Con fondo verde (lo mejor):**
- ffmpeg: `chromakey` (o `colorkey`) + `despill` para quitar el reflejo verde de pelo y piel. Ajustar similitud y mezcla en un fotograma difícil (pelo suelto, manos rápidas) antes de procesar todo.
- Consejos de estudio para Hugo: tela verde lisa sin arrugas y bien iluminada por separado, actriz a 1,5–2 m de la tela, nada de ropa verde ni joyas brillantes, luz principal suave en la actriz, grabar en 4K a 30 fps con obturación rápida para que las manos no salgan borrosas.
**Sin fondo verde:**
- Recorte por segmentación de personas fotograma a fotograma (rembg o modelos de matting de vídeo). Más lento y peor en el pelo; suavizar bordes y estabilizar la máscara entre fotogramas para que no "tiemble".
**Siempre:** igualar luz y color de la actriz con el fondo nuevo (temperatura, dirección de luz, desenfoque del fondo, grano igual en ambos). Una sombra suave en el suelo o una luz de contorno naranja integran mucho.

## 2. Animaciones 3D
**Three.js dentro de Remotion (@remotion/three)** para lo que va sincronizado con el montaje:
- Logo del caballo naranja en 3D (pedir el modelo o el vector del logo a Hugo; extruir el SVG si no hay modelo).
- Bolas 3D de resultados, monedas, iconos, texto extruido con cifras, gráficas de barras 3D que crecen, casa modular que se monta por piezas (constructoras), pantallas de móvil flotando con el dashboard (SaaS e infoproductos).
- Materiales: naranja #FF6A1A satinado, negro mate, luz principal cálida + luz de contorno; profundidad de campo suave. Movimientos con spring, nunca lineales.
**Blender (paquete bpy de Python, se instala aquí)** para renders más realistas: secuencia PNG o vídeo con transparencia para componer encima del vídeo.
**Modelos 3D de terceros:** solo con licencia que permita uso comercial (CC0 o similar) y comprobada. Nada de personajes, marcas ni logos ajenos.

## 3. Imágenes y clips con IA
- **Imágenes:** Canva (conectado) genera y edita imágenes en 9:16 y quita fondos. Fijar una plantilla de prompt y cambiar solo el sujeto para que la serie sea coherente: `[sujeto], fotografía cinematográfica, estudio oscuro, luz de contorno naranja, sombras profundas, poca profundidad de campo, 9:16`.
- **Clips de vídeo:** los modelos de vídeo de Figma Weave (Veo, Kling y similares) una vez Hugo vincule su cuenta de Figma en Weave; Descript si se conecta. Clips de 3–5 s para ganchos, transiciones y b-roll.
- **Qué sí:** escenas conceptuales (una obra que se construye, un móvil lleno de notificaciones de leads, un despacho vacío que se llena), fondos, texturas, transiciones.
- **Qué no:** nunca presentar algo generado como trabajo real de un cliente (casas, resultados, capturas, testimonios). Nada de caras o voces de personas reales generadas o alteradas. Si una imagen fotorrealista puede confundir al que mira, indicarlo según las normas de Meta sobre contenido hecho con IA. Fotos reales del nicho siguen teniendo prioridad donde importa la credibilidad.

## 4. Flujo de trabajo
1. Marcar en el guion dónde va cada efecto (máximo 3–4 por AD de 30–45 s) y para qué frase.
2. Preparar los recursos antes del montaje (recorte de la actriz, renders 3D con transparencia, clips de IA) y guardarlos como biblioteca reutilizable por nicho.
3. Componer en Remotion con la pila de capas: fondo → actriz recortada → 3D y gráficos → gradación de color → grano y viñeta.
4. Render de prueba a baja resolución y hoja de contacto.

## 5. Revisión obligatoria
Mirar fotogramas de cada efecto: bordes del recorte limpios (pelo, manos, dedos), sin halo verde, sin parpadeo de máscara, luz coherente entre actriz y fondo, el 3D no tapa la cara, nada dentro de las zonas que tapa la interfaz de Instagram, y el efecto se entiende en menos de 1 segundo. Corregir y volver a comprobar antes de entregar.