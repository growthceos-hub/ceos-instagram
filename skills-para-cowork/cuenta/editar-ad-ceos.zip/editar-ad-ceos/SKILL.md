---
name: "editar-ad-ceos"
description: "Editar anuncios en vídeo de Ceos Growth para Meta Ads (9:16) a partir de clips brutos de la actriz, con el estilo de marca y las reglas de edición ya validadas por Hugo."
---

# Editar AD de Ceos Growth

Formato validado en AD 1 v5, AD 2 v3 y AD 3 (constructoras). Aplicar todo de serie sin esperar a que Hugo lo pida. Vale igual para infoproductos, SaaS y clientes (Ysolve, Mónica…): mismo flow, recursos del nicho.

## Velocidad (objetivo: primera versión buena a la primera)
- No preguntar nada que esta skill ya decide. Solo preguntar si falta material o una cifra no cuadra.
- Transcribir todos los clips de una vez y en paralelo en cuanto lleguen.
- Montar primero el corte de audio (guion + cortes) y validarlo; los recursos se construyen encima, nunca al revés.
- Construir los recursos como componentes reutilizables (tema de marca, tarjeta, contador, subtítulo, bola 3D) y reutilizarlos en cada AD de la serie: solo cambian textos y tiempos.
- Render de prueba a 540x960 y hoja de contacto antes del render final a 1080x1920. Un solo render final.
- Si el ordenador de Hugo está vinculado, leer los brutos de su carpeta y dejar el final en EDITADOS › AD n directamente.
- Si Hugo dice que manda varios ads, comprobar por la transcripción qué clips son de cada uno; si falta alguno, avisarle y seguir con los que hay.

## Entrada
- Clips IMG_xxxx.mov de iPhone (4K o 1080p vertical), una frase por clip, en orden de nombre.
- El conector de Drive NO descarga vídeos (los corta) ni los sube. Si no hay ordenador vinculado, pedir a Hugo que suba los clips o el .zip al chat. Para subir resultados, pasarle los MP4 para que los guarde él en CEOS GROWTH ADS 2026 › EDITADOS › AD n (o EDITADOS INFOPRODUCTOS), o hacerlo con el ordenador vinculado. Las carpetas sí se pueden crear con el conector.

## Color según el ad
- Ads propios de Ceos Growth: negro y naranja #FF6A1A; texto negro sobre las tarjetas naranjas.
- Ads para clientes: cambiar el color de acento al que pida Hugo (p. ej. rojo para Ysolve/software, verde para Mónica/psicóloga) con exactamente las mismas animaciones, tipografías y acabado. Texto sobre tarjetas de color en blanco. Estados de éxito en verde y de error en rojo claro.
- Recursos del nicho del cliente (software: terminal, código, móvil que se rompe, arquitectura, pilares; psicología: ciclos, iceberg síntoma/mecanismo, pasos, hoja de ruta; tono calmado y muy profesional).

## Guion (cero fallos)
1. Transcribir cada clip (Whisper small en español).
2. Corregir a mano lo que la transcripción entiende mal (leads, funnel, cuota fija, obras, formulario, MVP, onboarding, evitación, nombres de cliente…). Si una frase es dudosa, retranscribir con audio normalizado o por trozos.
3. Tras cortar, volver a transcribir cada tramo del montaje final y comprobar la energía de audio justo después de cada corte: ninguna palabra cortada. Ignorar clics de menos de 0,2 s al inicio del clip.
4. Avisar a Hugo si una cifra dicha no cuadra con la oferta (p. ej. "10 profesionales" vs 12), pero rotular lo que dice la actriz.
5. Nunca inventar reseñas, testimonios ni cifras (tampoco porcentajes calculados a partir de las cifras dichas). Si el guion dice "esto es lo que opinan de nosotros", pedir capturas reales y recrearlas animadas (tarjetas en cascada con foto recortada, nombre, cargo, estrellas y extracto literal) sin cortar la voz.
6. Frases que no se entienden: taparlas con una tarjeta en vez de subtítulo y avisar a Hugo en el correo. Tomas repetidas o palabras duplicadas entre clips: recortar para que suene seguido.

## Montaje
- Fluidez con dopamina, pero SIN cortar NUNCA la voz de la actriz (regla para todos los ads):
  - Detectar silencios a -44 dB y quitar solo las pausas de más de ~0,25 s; los huecos cortos entre palabras se dejan.
  - Antes de fijar cada corte, alargar el borde mientras siga habiendo energía de voz (hasta +0,3 s al final y +0,25 s al inicio), para no comerse finales de palabra ("-s", "-mente", consonantes suaves) ni arranques.
  - Márgenes: ~0,07 s antes de hablar, ~0,09 s después en los cortes internos y ~0,12 s al final de cada clip.
  - No descartar trozos cortos de voz salvo que estén aislados (más de 0,4 s de hueco) al principio o al final del clip.
  - Fundidos de audio muy cortos en cada corte (8–12 ms) para que no se coman sílabas.
  - El ritmo se consigue acelerando todo el vídeo un 7 % (atempo 1,07) y con los golpes visuales, no apretando los cortes.
  - Comprobar tras cortar: transcribir cada tramo y medir la energía en los 20 ms del borde de cada corte; si hay voz, alargar y rehacer.
- Zoom alterno entre planos (1,00 / 1,15) + empuje lento continuo; golpe de zoom en el primer segundo. Algo se mueve en los primeros 15 fotogramas.
- En cada cambio de clip: golpe de zoom, pequeña sacudida, destello del color de acento y efecto de impacto. Dentro de un mismo clip, zoom suave alterno en los saltos.
- Nunca más de 3 s sin un cambio visual (zoom, recurso o subtítulo nuevo).
- Planos sin cara útil —pared/techo, piernas, plano abierto con el foco detrás, o cuando está leyendo el móvil— usar solo su audio y taparlos con una escena animada a pantalla completa. Detectarlos por cara (sin cara en más del 50 % del plano = escena completa) y confirmarlo en la hoja de contacto, clip a clip.
- Si falta el CTA, reutilizar el de otro vídeo de la serie (el del formulario).

## Recursos visuales
- Marca: negro #0A0908 y el color de acento del ad; Bricolage Grotesque (titulares), Instrument Serif itálica (frase de apoyo), JetBrains Mono (etiquetas). Caballo naranja como logo en los propios. Un solo elemento de acento protagonista por fotograma.
- Sin cabecera arriba (ni logo ni etiqueta de nicho): solo barra de progreso fina.
- NADA tapa la cara: detectar cara por plano y colocar tarjetas debajo de la barbilla o encima de la cabeza. Todo dentro del 75 % central vertical (la interfaz de Instagram tapa arriba y abajo).
- Tarjetas animadas de marca (contadores, tachados, gráficas, pasos 01/02, notificaciones, CTA con botón) en los momentos clave; no en todas las frases.
- Bolas 3D solo cuando la actriz hace un gesto concreto señalando un resultado (dedos, mano levantada): aparecen desde la mano y flotan al lado de la cabeza. No perseguir las manos todo el rato.
- Capturas reales (resultados de Meta, reseñas) como pop-up recreado en HTML y animado, sin cortar la voz; pixelar logos o nombres cuando haga falta por privacidad.
- Fondo: fotos reales del nicho (villas de lujo en constructoras; nada 3D generado) integradas tras la actriz con recorte por silueta, solo en el gancho y en el caso real. Sin sobrecargar la pared.
- Sin pantalla de cierre: el vídeo acaba cuando ella termina el CTA.

## Oficio de animación (lo que separa un AD pro de uno "hecho con IA")
- Nunca movimiento lineal: entradas con spring, salidas con ease-in, todo con clamp.
- Cada entrada anima 2–3 propiedades a la vez (opacidad + subida + escala 0,94→1). Un fundido solo está prohibido.
- Escalonar: palabras cada 3 fotogramas, filas o tarjetas cada 4–5. Nada entra todo a la vez.
- Las salidas existen y son más rápidas que las entradas (~10 fotogramas frente a ~20).
- Ritmo GOLPE → quieto (15–20 fotogramas) → construir → GOLPE. Los momentos quietos dan sensación cara; el movimiento constante, amateur.
- Lo que está más de 2 s en pantalla "respira" (micro-movimiento suave).
- Cifras con contador animado y números tabulares. Fotos siempre con Ken Burns lento (escala 1→1,08 + paneo).

## Subtítulos
- Solo cuando NO hay ningún recurso en pantalla.
- SIMPLES en todos los ads: frase corta en blanco, sin resaltar palabra por palabra ni colorear palabras; entran con un fundido y una subida suaves.
- Siempre debajo de la barbilla, nunca sobre la cara. Muy legibles en móvil.

## Audio
- Voz: filtro paso alto, compresión suave, -15 LUFS.
- Música tipo anuncio con urgencia (~126 BPM), alta y presente pero bajando sola cuando habla ella (sidechain); algo más suave en nichos sensibles como psicología. Golpes de recurso sobre el beat cuando se pueda. Redobles antes de la oferta y de las plazas.
- Efectos suaves: roce en cortes, "toc" al entrar tarjetas, campanita en las bolas 3D. El efecto empieza 2–3 fotogramas ANTES de que llegue lo visual (tarde se nota roto).
- Mezcla final ~-14 LUFS.

## Acabado y entrega
- Micro-nitidez, viñeta sutil y grano fino (siempre por encima de todo).
- MP4 H.264 1080x1920 30 fps, <30 MB (bajar el bitrate a ~2900k si el vídeo pasa de ~60 s).
- Antes de entregar: hoja de contacto de todo el vídeo y fotogramas sueltos de cada recurso. Mirarlos de verdad y comprobar: nada pisa la cara, nada toca los bordes, nada aparece antes de su entrada ni queda tras su salida, un solo acento protagonista por fotograma, texto legible. Corregir y volver a comprobar.
- Entregar el vídeo con un resumen breve y las dudas de guion que haya (cifras dichas, frases dudosas, tomas recortadas), y avisar por correo a growthceos@gmail.com cuando esté.