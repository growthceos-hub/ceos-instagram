---
name: "editar-ad-ceos-2"
description: "Editar ADs de Ceos Growth (9:16) con el estilo v2: subtítulos sin resaltar, música a nivel constante y animaciones 3D. Usar cuando Hugo pida la edición 2 o \"editar ad 2\"."
---

# Editar AD de Ceos Growth — versión 2

Igual que editar-ad-ceos en todo, salvo tres diferencias (marcadas con ★ V2). Aplicar todo de serie sin esperar a que Hugo lo pida. Vale para constructoras, infoproductos, SaaS y clientes (Ysolve, Mónica…): mismo flow, recursos del nicho.

## Velocidad (objetivo: primera versión buena a la primera)
- No preguntar nada que esta skill ya decide. Solo preguntar si falta material o una cifra no cuadra.
- Transcribir todos los clips de una vez y en paralelo en cuanto lleguen.
- Montar primero el corte de audio (guion + cortes) y validarlo; los recursos se construyen encima, nunca al revés.
- Construir los recursos como componentes reutilizables (tema de marca, tarjeta, contador, subtítulo, bola 3D, objeto 3D) y reutilizarlos en cada AD de la serie: solo cambian textos y tiempos.
- Render de prueba a 540x960 y hoja de contacto antes del render final a 1080x1920. Un solo render final.
- Si el ordenador de Hugo está vinculado, leer los brutos de su carpeta y dejar el final en EDITADOS › AD n directamente.

## Entrada
- Clips IMG_xxxx.mov de iPhone (4K vertical), una frase por clip, en orden de nombre.
- El conector de Drive NO descarga vídeos (los corta) ni los sube. Si no hay ordenador vinculado, pedir a Hugo que suba los clips o el .zip al chat. Para subir resultados, pasarle los MP4 para que los guarde él en CEOS GROWTH ADS 2026 › EDITADOS › AD n (o EDITADOS INFOPRODUCTOS), o hacerlo con el ordenador vinculado.

## Guion (cero fallos)
1. Transcribir cada clip (Whisper small en español).
2. Corregir a mano lo que la transcripción entiende mal (leads, funnel, cuota fija, obras, formulario…). Si una frase es dudosa, retranscribir con audio normalizado o por trozos.
3. Tras cortar, volver a transcribir cada tramo del montaje final y comprobar la energía de audio justo después de cada corte: ninguna palabra cortada.
4. Avisar a Hugo si una cifra dicha no cuadra con la oferta (p. ej. "10 profesionales" vs 12), pero rotular lo que dice la actriz.

## Montaje
- Cortes apretados: ~0,10 s antes de hablar y ~0,13 s después. Nada de aire muerto (dopamina).
- Cortar pausas internas de más de 0,5 s.
- Zoom alterno entre planos (1,00 / 1,15) + empuje lento continuo; golpe de zoom en el primer segundo. Algo se mueve en los primeros 15 fotogramas.
- Nunca más de 3 s sin un cambio visual (zoom, recurso o subtítulo nuevo).
- Clips grabados a pared/techo sin cara: usar solo su audio y taparlos con una escena animada a pantalla completa.

## Recursos visuales
- Marca: negro #0A0908 y naranja #FF6A1A (o el color del cliente); Bricolage Grotesque (titulares), Instrument Serif itálica (frase de apoyo), JetBrains Mono (etiquetas). Caballo naranja como logo. Un solo elemento de color protagonista por fotograma.
- Sin cabecera arriba (ni logo ni etiqueta de nicho): solo barra de progreso fina.
- NADA tapa la cara: detectar cara por plano y colocar tarjetas debajo de la barbilla o encima de la cabeza. Todo dentro del 75 % central vertical (la interfaz de Instagram tapa arriba y abajo).
- Tarjetas animadas de marca (contadores, tachados, gráficas, pasos 01/02, CTA con botón y "<24 h") en los momentos clave; no en todas las frases.
- Bolas 3D solo cuando la actriz hace un gesto concreto señalando un resultado (dedos, mano levantada): aparecen desde la mano y flotan al lado de la cabeza. No perseguir las manos todo el rato.
- ★ V2 — Animaciones 3D para más dinamismo: en 3–5 momentos del AD (gancho, cifra clave, oferta, CTA) meter una animación 3D real (Three.js renderizado a vídeo, fondo transparente): tarjetas o cifras que giran en perspectiva, iconos/objetos del nicho con volumen y luz de marca (llave, casa en línea, gráfica en barras 3D, moneda, check), texto extruido que entra con giro. Con sombras suaves y reflejo del color de marca. Nunca casas 3D realistas (parecen "Minecraft"): en constructoras, 3D solo en objetos gráficos/iconos, y las casas siguen siendo fotos reales. Misma regla de cara y márgenes que el resto.
- Fondo: fotos reales del nicho (villas de lujo en constructoras; nada 3D generado) integradas tras la actriz con recorte por silueta, solo en el gancho y en el caso real. Sin sobrecargar la pared.
- Sin pantalla de cierre: el vídeo acaba cuando ella termina el CTA.

## Oficio de animación (lo que separa un AD pro de uno "hecho con IA")
- Nunca movimiento lineal: entradas con spring, salidas con ease-in, todo con clamp.
- Cada entrada anima 2–3 propiedades a la vez (opacidad + subida + escala 0,94→1). Un fundido solo está prohibido.
- Escalonar: palabras cada 3 fotogramas, filas o tarjetas cada 4–5. Nada entra todo a la vez.
- Las salidas existen y son más rápidas que las entradas (~10 fotogramas frente a ~20).
- Ritmo GOLPE → quieto (15–20 fotogramas) → construir → GOLPE. Los momentos quietos dan sensación cara; el movimiento constante, amateur.
- Lo que está más de 2 s en pantalla "respira" (micro-movimiento suave; en 3D, rotación lenta de pocos grados).
- Cifras con contador animado y números tabulares. Fotos siempre con Ken Burns lento (escala 1→1,08 + paneo).

## Subtítulos
- Solo cuando NO hay ningún recurso en pantalla.
- ★ V2 — Subtítulos simples: frase completa visible, SIN resaltar la palabra activa (nada de karaoke, ni cambio de color, ni escala, ni subrayado por palabra). Texto blanco con sombra suave; la frase entra y sale entera.
- Siempre debajo de la barbilla, nunca sobre la cara. Muy legibles en móvil.

## Audio
- Voz: filtro paso alto, compresión suave, -15 LUFS.
- ★ V2 — Música a nivel constante durante TODO el vídeo: sin sidechain ni bajadas cuando habla ella, sin subidas ni fundidos en medio. Mismo volumen del primer al último fotograma, ajustado para que se oiga presente pero la voz se entienda perfectamente (música ~8–10 dB por debajo de la voz). Tipo anuncio con urgencia (~126 BPM). Golpes de recurso sobre el beat cuando se pueda.
- Efectos suaves: roce en cortes, "toc" al entrar tarjetas, campanita en las bolas 3D, "whoosh" suave en las entradas 3D. El efecto empieza 2–3 fotogramas ANTES de que llegue lo visual (tarde se nota roto).
- Mezcla final ~-14 LUFS.

## Acabado y entrega
- Micro-nitidez, viñeta sutil y grano fino (siempre por encima de todo).
- MP4 H.264 1080x1920 30 fps, <30 MB.
- Antes de entregar: hoja de contacto de todo el vídeo y fotogramas sueltos de cada recurso y de cada animación 3D. Mirarlos de verdad y comprobar: nada pisa la cara, nada toca los bordes, nada aparece antes de su entrada ni queda tras su salida, un solo color protagonista por fotograma, texto legible, subtítulos sin resaltado. Corregir y volver a comprobar.
- Entregar el vídeo con un resumen breve y las dudas de guion que haya.