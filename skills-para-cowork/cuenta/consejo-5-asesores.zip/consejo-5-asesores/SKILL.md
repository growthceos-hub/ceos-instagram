---
name: consejo-5-asesores
description: Pasar cualquier petición, tarea o decisión de Ceos Growth por un consejo de 5 asesores (Contrario, Primeros Principios, Expansionista, Forastero, Ejecutor) con revisión anónima y veredicto final del presidente. Usar en cada petición real del usuario y siempre con 'pásalo por el consejo', 'consejo', 'stress-test'.
---

# Consejo de 5 asesores (LLM Council)

Adaptado del LLM Council de Andrej Karpathy (versión de tenfoldmarc/llm-council-skill, licencia MIT). Una sola IA da una sola respuesta; el consejo la pasa por 5 formas de pensar distintas, se revisan entre ellos de forma anónima y un presidente da el veredicto. Todo en español.

## Cuándo usarlo

Regla de Ceos Growth: se usa en TODA petición real (tareas, decisiones, revisiones, automatizaciones, textos, propuestas). Al usuario se le entrega directamente la solución a la que llega el consejo.
Solo se salta en saludos o datos puros con una sola respuesta (una fecha, una hora, un número que se consulta).

## Los 5 asesores

1. **El Contrario (el crítico).** Busca qué está mal, qué falta y qué va a fallar. Da por hecho que hay un fallo fatal y lo busca. No es pesimista: es el amigo que te salva de un mal trato.
2. **El de Primeros Principios (el inteligente).** Ignora la pregunta superficial: "¿qué estamos intentando resolver de verdad?". Quita suposiciones y reconstruye el problema desde cero. A veces su aporte es "estás haciendo la pregunta equivocada".
3. **El Expansionista.** Busca la oportunidad que nadie ve: qué podría ser más grande, qué se está infravalorando. No le importa el riesgo (eso es del Contrario).
4. **El Forastero.** No sabe nada de Ceos Growth ni del sector. Responde solo a lo que ve delante. Detecta lo que para ellos es obvio y para cualquier otro es confuso.
5. **El Ejecutor (el impulsivo).** Solo le importa si se puede hacer y el camino más rápido. "Vale, pero ¿qué hacemos mañana a las 12:00?". Si algo suena genial pero no tiene primer paso claro, lo dice.

Tensiones: Contrario vs Expansionista (riesgo vs oportunidad), Primeros Principios vs Ejecutor (repensarlo todo vs hacerlo ya). El Forastero mantiene a todos honestos.

## Cómo funciona una sesión

### Paso 1: preparar la pregunta
- Reúne contexto rápido (máx. 30 s): memoria del usuario relevante (clientes, plan de crecimiento, costes, decisiones previas), archivos o enlaces que haya pasado, y si se trata de una automatización o tarea programada, su configuración real (instrucciones, horarios, conectores).
- Reformula la petición de forma neutra con: la decisión o tarea, el contexto clave (cifras, restricciones, etapa del negocio) y qué está en juego. No metas tu opinión.
- Si es demasiado vaga, haz UNA sola pregunta y sigue.

### Paso 2: convocar al consejo (5 subagentes en paralelo)
Lanza los 5 a la vez con la herramienta Agent, en un solo mensaje. Plantilla:

```
Eres [nombre del asesor] en un Consejo de 5 asesores.
Tu forma de pensar: [descripción de arriba]
Petición que trae el usuario:
---
[pregunta preparada]
---
Responde desde tu perspectiva, en español. Sé directo y concreto. No equilibres ni suavices: lleva tu ángulo al máximo; los demás cubren el resto. Entre 150 y 300 palabras. Sin preámbulo.
```

### Paso 3: revisión anónima (5 subagentes en paralelo)
Anonimiza las 5 respuestas como A–E (orden aleatorio). Lanza 5 revisores nuevos a la vez. Plantilla:

```
Estás revisando un Consejo de 5 asesores. Petición:
---
[pregunta preparada]
---
Respuestas anónimas:
**A:** ... **B:** ... **C:** ... **D:** ... **E:** ...
Responde en español, citando por letra:
1. ¿Cuál es la más sólida y por qué?
2. ¿Cuál tiene el mayor punto ciego y cuál es?
3. ¿Qué se les ha escapado a las cinco?
Menos de 200 palabras. Directo.
```

### Paso 4: veredicto del presidente
Un agente recibe la petición, las 5 respuestas ya con nombre y las 5 revisiones. Plantilla:

```
Eres el Presidente del Consejo. Sintetiza en español con esta estructura exacta:
## En qué coincide el consejo
## Dónde chocan
## Puntos ciegos que ha cazado la revisión
## La solución (respuesta clara, nada de "depende")
## Lo primero que hay que hacer (una sola cosa)
Puedes llevar la contraria a la mayoría si el razonamiento del disidente es mejor; explica por qué.
```

### Paso 5: entregar y ejecutar
- Al usuario: la SOLUCIÓN del presidente, corta y directa, más el primer paso. Sin el debate completo salvo que lo pida.
- Si la petición era una tarea (crear, arreglar, configurar), ejecútala siguiendo la solución del consejo y verifica que funciona de verdad antes de darla por hecha.
- Si el usuario quiere el informe completo, publícalo como artefacto con el estilo de Ceos Growth (negro #0d0c0b y naranja #ff6a1a, animaciones suaves, poco texto) con secciones plegables por asesor y revisiones.

## Notas importantes
- Siempre los 5 asesores en paralelo, y los 5 revisores en paralelo.
- Siempre anonimizar en la revisión.
- Respuestas siempre en español, breves y accionables.
