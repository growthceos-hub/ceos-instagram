---
name: "analizar-meta-ads-ceos"
description: "Analizar y diagnosticar campañas de Meta Ads de Ceos Growth o de sus clientes con datos reales (Windsor.ai o exportes), y dar a Wilfredo acciones claras."
---

# Analizar Meta Ads · Ceos Growth

Para cuando Hugo pregunte cómo van las campañas, por qué sube el CPL, qué anuncio funciona o qué hacer con una cuenta. Respuesta en español, corta y accionable para Wilfredo (traffiker).

## Datos
1. Sacar los datos reales con Windsor.ai (conector `facebook`): get_connectors para ver las cuentas, get_fields si hace falta, y get_data. Nunca estimar cifras a ojo.
2. Mínimo: gasto, impresiones, alcance, frecuencia, CPM, clics en el enlace, CTR del enlace, leads/resultados, coste por resultado, reproducciones de 3 s y ThruPlays (vídeo), rankings de calidad, interacción y conversión. Por día, últimos 14–30 días, a nivel campaña, conjunto y anuncio.
3. Si hay muchos datos, guardarlos en archivo y calcular con código.
4. Leads de clientes: cruzar con su Excel «LEADS | Cliente» de Drive para ver la calidad, no solo el volumen.

## Reglas de diagnóstico
1. **Nivel correcto.** Con presupuesto de campaña (Advantage+/CBO) se juzga la campaña; con varios anuncios en un conjunto, el conjunto. No juzgar piezas sueltas de un sistema que optimiza el total.
2. **Fase de aprendizaje.** Sale tras ~50 resultados en 7 días desde la última edición importante. Si está aprendiendo: todo es provisional y no se toca. "Aprendizaje limitado" = poco presupuesto o demasiados conjuntos → consolidar.
3. **Efecto desglose.** Nunca recomendar apagar una ubicación, edad o segmento solo porque su coste medio sea más alto. Meta optimiza el coste del siguiente resultado, no la media. Cualquier cambio así se plantea como prueba, no como orden.
4. **Fluctuación normal vs. problema.** Normal: ±20–30 % diario, fines de semana, aprendizaje. Problema: subida >50 % varios días seguidos, entrega casi a cero, más gasto con menos conversión. Evaluar ventanas de 7+ días.
5. **Fatiga creativa.** CTR cae >20 % en 14 días con frecuencia >3 → hace falta creativo nuevo (pasar a producción: nuevo AD o nuevo gancho).
6. **Rankings.** Calidad baja → creativo flojo o "clickbait". Interacción baja → gancho flojo. Conversión baja → formulario/landing o encaje oferta-público. Todo bajo → público y creativo no encajan. Sin datos con <500 impresiones.
7. **Presupuesto.** Cada conjunto necesita presupuesto semanal ≥5× el coste por resultado objetivo para salir de aprendizaje. Mínimo recomendado de Ceos: 15 €/día.

## Referencias orientativas (vídeo vertical, captación de leads)
- Hook rate (reproducciones 3 s / impresiones): bien 30–40 %, muy bien 50 %+, flojo <25 %. Si falla, el problema son los 3 primeros segundos del AD.
- CTR del enlace: bien 1–2 %, flojo <0,8 %.
- Frecuencia en captación: sana 1,5–2,5; alarma >3,5.
- Son referencias generales; manda la comparación con el histórico de la propia cuenta.

## Garantías de Ceos (comprobar siempre en clientes)
- CPL máximo 15–20 €: si se supera de forma sostenida, toca rehacer los anuncios. Avisar en cuanto un cliente se acerque.
- 90 % de leads cualificados (persona real, formulario completo, teléfono verificado, sabe qué vende el cliente y en qué rango de precio).

## Cambios en la cuenta
Windsor puede crear, pausar y cambiar presupuestos. Solo ejecutar un cambio después de que Hugo o Wilfredo confirmen ese cambio concreto. Por defecto, proponer; no tocar.

## Formato de respuesta
1. Estado en una línea (bien / vigilar / actuar) por cuenta o cliente.
2. Los 2–3 hallazgos que importan, cada uno con su dato.
3. Acciones para Wilfredo, ordenadas por impacto, planteadas como pruebas con lo que se espera que pase.
4. Si falta creativo: qué tipo de AD o gancho pedir a producción.
Nombrar "clics en el enlace" (no "clics" a secas) y "cuentas alcanzadas" en vez de "personas".