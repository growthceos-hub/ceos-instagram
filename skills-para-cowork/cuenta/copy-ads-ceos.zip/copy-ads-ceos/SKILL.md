---
name: "copy-ads-ceos"
description: "Escribir guiones para la actriz y copys de Meta Ads de Ceos Growth y sus clientes, por nicho, con ganchos fuertes y sin sonar a IA."
---

# Copy y guiones de ADs · Ceos Growth

Para guiones de vídeo (lo que dice la actriz), textos del anuncio (texto principal, titular, descripción), ganchos y variantes para pruebas. Siempre en español de España, cercano y directo.

## Antes de escribir
- Nicho y público exacto: constructoras (casas modulares o normales para particulares), SaaS (crear o vender por suscripción), infoproductos, o el cliente concreto (p. ej. Mónica, psicóloga: muy profesional).
- Oferta vigente y garantías: solo prometer lo que está en el contrato. Si una garantía aún no está firmada en contrato, no se anuncia.
- Nunca inventar cifras, casos, testimonios ni resultados. Si falta un dato real, dejar [DATO] y avisar.

## Estructura del guion (vertical, 30–60 s)
1. **Gancho (0–3 s):** una sola idea que para el scroll. Es lo que más decide el resultado (hook rate). Escribir siempre 3–5 ganchos alternativos para probar.
2. **Contexto (3–6 s):** una frase que conecta el gancho con el problema.
3. **Cuerpo:** 3–4 golpes cortos. Cada frase = un clip de la actriz, una idea, fácil de decir de corrido.
4. **Prueba:** caso real, cifra real o mecanismo concreto.
5. **CTA:** una acción, con fricción baja y urgencia honesta (plazas, fecha real).
Marcar en el guion dónde va un recurso visual (contador, tachado, gesto con la mano para las bolas 3D) para que edición lo tenga claro.

## Marcos según la pieza
- AD corto y ganchos: PAS (problema → agitar → solución) o AIDA.
- Anuncio de caso real: Antes → Después → Puente.
- Landing o hero: Promesa → Imagen del resultado → Prueba → Empujón.
- Email o secuencia: calificar ("si tienes una constructora…") → entender → enseñar algo → transición a la oferta.

## Fórmulas de gancho
- Pregunta que duele: "¿Cuántos presupuestos has enviado este mes que nunca contestaron?"
- Cifra concreta y creíble.
- Error común: "El error que hace que tu publicidad traiga curiosos y no clientes."
- Contraste: "No necesitas más leads. Necesitas leads que compren."
- Resultado + plazo realista.

## Políticas de Meta (evitar rechazos)
- No afirmar ni insinuar atributos personales del que mira: salud física o mental, situación económica, edad, etc. ("¿Tienes ansiedad?" no; "Si trabajas con pacientes de ansiedad…" sí). Clave en psicología.
- Nada de ingresos garantizados ni resultados exagerados en infoproductos.
- Vivienda: comprobar si la campaña debe declararse en categoría especial.

## Que no suene a IA
Quitar siempre:
- Palabras infladas: "potenciar", "revolucionario", "sin precedentes", "clave", "integral", "robusto", "en el panorama actual", "llevar al siguiente nivel", "desbloquear".
- Estructuras de plantilla: "no solo X, sino también Y", tríadas forzadas, "en un mundo donde…", cierres motivacionales vacíos.
- Exceso de emojis, negritas y rayas largas.
Pasada final: leerlo en voz alta como la actriz. Si algo no se diría así en una conversación, se reescribe. Frases cortas, palabras normales, alguna frase de ritmo distinto.

## Entrega
- Guion en tabla: nº de clip | frase | recurso en pantalla.
- 3–5 ganchos alternativos.
- Copy del anuncio: 2 textos principales (uno corto, uno largo), 3 titulares ≤40 caracteres, 1 descripción.
- Sin explicaciones largas: listo para pasar a la actriz y a Wilfredo.